

<?php $__env->startSection('contents'); ?>

<h1>submit order successfully</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\flower_store-app\resources\views/layouts/thankyou.blade.php ENDPATH**/ ?>